﻿using System;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace JsonSerialization.Api
{
    public class WeatherForecastConverter : JsonConverter<WeatherForecast>
    {
        public override WeatherForecast Read(ref Utf8JsonReader reader, Type typeToConvert, JsonSerializerOptions options)
        {
            var jsonElement = JsonSerializer.Deserialize<JsonElement>(ref reader, new JsonSerializerOptions
            {
                PropertyNamingPolicy = JsonNamingPolicy.CamelCase
            });

            if (!jsonElement.TryGetProperty("scale", out var property))
                throw new JsonException($"Required property 'scale' is missing");

            var scaleType = property.ValueKind switch
            {
                JsonValueKind.String => Enum.TryParse<Scale>(property.GetString(), out var stringKind) ? stringKind :
                    throw new JsonException($"Cant convert value {property.GetString()} to Scale Enum"),
                JsonValueKind.Number => (Scale)property.GetInt32(),
                _ => throw new JsonException($"Cant convert value {property.GetRawText()} to Scale Enum")
            };

            return scaleType switch
            {
                Scale.Celsius => JsonSerializer.Deserialize<WeatherForecastCelsius>(jsonElement.GetRawText(), new JsonSerializerOptions
                {
                    PropertyNamingPolicy = JsonNamingPolicy.CamelCase
                }),
                Scale.Fahrenheit => JsonSerializer.Deserialize<WeatherForecastFahrenheit>(jsonElement.GetRawText(), new JsonSerializerOptions
                {
                    PropertyNamingPolicy = JsonNamingPolicy.CamelCase
                }),
                Scale.Kelvin => JsonSerializer.Deserialize<WeatherForecastKelvin>(jsonElement.GetRawText(), new JsonSerializerOptions
                {
                    PropertyNamingPolicy = JsonNamingPolicy.CamelCase
                }),
                _ => throw new JsonException("Cant parse request")
            };
        }

        public override void Write(Utf8JsonWriter writer, WeatherForecast value, JsonSerializerOptions options)
        {
            switch (value)
            {
                case WeatherForecastCelsius request:
                    JsonSerializer.Serialize(writer, request, new JsonSerializerOptions
                    {
                        PropertyNamingPolicy = JsonNamingPolicy.CamelCase
                    });
                    break;
                case WeatherForecastFahrenheit request:
                    JsonSerializer.Serialize(writer, request, new JsonSerializerOptions
                    {
                        PropertyNamingPolicy = JsonNamingPolicy.CamelCase
                    });
                    break;
                case WeatherForecastKelvin request:
                    JsonSerializer.Serialize(writer, request, new JsonSerializerOptions
                    {
                        PropertyNamingPolicy = JsonNamingPolicy.CamelCase
                    });
                    break;
                default: throw new JsonException($"Not supported value");
            }
        }
    }
}