using System;
using System.Text.Json.Serialization;

namespace JsonSerialization.Api
{
    public enum Scale
    {
        Celsius = 1,
        Fahrenheit = 2,
        Kelvin = 3
    }

    [JsonConverter(typeof(WeatherForecastConverter))]
    public class WeatherForecast
    {
        public virtual Scale Scale { get; }
        public DateTime Date { get; set; }
    }

    public class WeatherForecastCelsius : WeatherForecast
    {
        public override Scale Scale { get; } = Scale.Celsius;
        public int TemperatureC { get; set; }
    }

    public class WeatherForecastFahrenheit : WeatherForecast
    {
        public override Scale Scale { get; } = Scale.Fahrenheit;
        public int TemperatureF { get; set; }
    }

    public class WeatherForecastKelvin : WeatherForecast
    {
        public override Scale Scale { get; } = Scale.Kelvin;
        public int TemperatureK { get; set; }
    }
}
