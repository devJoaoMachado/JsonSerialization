﻿using Microsoft.AspNetCore.Mvc;

namespace JsonSerialization.Api.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class WeatherForecastController : ControllerBase
    {
        /// <summary>
        /// {
        ///  "scale": 1,
        ///  "date": "2022-01-21T01:45:34.773Z",
        ///  "temperatureC": 100
        /// }
        /// {
        ///  "scale": 2,
        ///  "date": "2022-01-21T01:45:34.773Z",
        ///  "temperatureF": 100
        /// }
        /// {
        ///    "scale": 3,
        ///  "date": "2022-01-21T01:45:34.773Z",
        ///  "temperatureK": 100
        /// }
        /// </summary>
        /// <param name="weatherForecast"></param>
        /// <returns></returns>
        [HttpPost]
        public IActionResult Post([FromBody] WeatherForecast weatherForecast)
        {
            return new OkObjectResult(weatherForecast);
        }
    }
}
